

<?php $__env->startSection('title-block'); ?>
    About
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1>About</h1>
    <p>
        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ullam aliquam rem consectetur modi sit 
        eum explicabo dolorem sunt ducimus earum quaerat, qui debitis tenetur accusamus culpa eos? Repellat,
        vel asperiores!
    </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelYoutube\resources\views/about.blade.php ENDPATH**/ ?>