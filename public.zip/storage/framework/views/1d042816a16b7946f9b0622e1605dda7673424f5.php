<?php $__env->startSection('aside'); ?>
    <div class="aside">
        <h4>Bokovaya panel</h4>
        <?php echo $__env->yieldSection(); ?>
    </div><?php /**PATH C:\xampp\htdocs\laravelYoutube\resources\views/inc/aside.blade.php ENDPATH**/ ?>