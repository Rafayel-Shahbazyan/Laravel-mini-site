<div class="jumbotron">
    <div class="container">
        <h1>Privet vsem</h1>
        <p>Lorem ipsum dolor sit amet consectetur, adiimos, vel fugiat quas doloremque 
            tempore praesentium, dolores quisquam. A aperiam repellendus consequuntur!
            Soluta reprehenderit eligendi et?</p>
    </div>
</div><?php /**PATH C:\xampp\htdocs\laravelYoutube\resources\views/inc/hero.blade.php ENDPATH**/ ?>