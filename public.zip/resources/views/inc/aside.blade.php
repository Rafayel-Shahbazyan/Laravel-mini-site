@section('aside')
    <div class="aside">
        <h4>Bokovaya panel</h4>
        @show
    </div>